#!/usr/bin/env bash
echo "mock-overuse-gate: nothing to install, this skill is markdown only."
